import React, { Component } from 'react';
import './App.css';
import Create from './create'
import Get from './Get'
import {BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'

class App extends Component {
  render() {
    return (
      <Router>
      <div >
        <h1>Product Shoppee..!</h1>
        <ul>
          <li><Link to={'/create'} >Add Product</Link></li>
          <li><Link to={'/Get'}>Product List</Link></li>
        </ul>
        <hr/>
        <Switch>
          <Route exact path='/create' component={Create}/>
          <Route exact path='/Get' component={Get}/> 
        </Switch>

      </div>
      </Router>
    );
  }
}

export default App;
