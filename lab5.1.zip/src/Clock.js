import React from 'react';
//no need to import React and Component seperately as we have use React.Component
class Clock extends React.Component{

    constructor(props){
         super(props);
        this.state={
            name:'Ram'
        }
    }

    render(){
        console.log('Rendering Clock...')
    return <div>
    <h1>IGATE</h1></div>
    }

}

export default Clock;