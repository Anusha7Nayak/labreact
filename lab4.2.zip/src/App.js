import React, { Component } from 'react';

import './App.css';
import NameForm from './components/inputtext';
class App extends Component {
  render() {
    return (
     <NameForm/>
    );
  }
}

export default App;
