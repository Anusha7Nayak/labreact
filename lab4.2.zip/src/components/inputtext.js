import React, { Component } from 'react';

export default class NameForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      item: [],
      itemList: []
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleChange(event) {

    this.setState({ item: event.target.value });
  }
  handleSubmit(event) {
    event.preventDefault();
    const items = this.state.itemList
    items.push(this.state.item)
    this.setState({ itemList: items })
    console.log(this.state.itemList)
    this.setState({
      item: ''
    })
  }
  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <label>
            Name:
            <input type="text" value={this.state.item} onChange={this.handleChange} />
          </label>
          <input type="submit" value="Submit" />
          <br />
          <select>
            {
              this.state.itemList.map((name, index) => <option key={index}>{name}</option>
              )}
          </select>
        </form>
      </div>
    );
  }
}
