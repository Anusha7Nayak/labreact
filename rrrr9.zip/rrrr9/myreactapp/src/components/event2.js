import React from 'react'


export class Event1 extends React.Component{

    constructor(props){
    super();
    this.age=props.age;
    }

    update(){
        this.age=this.props.age;
        console.log("before" +this.age);
        this.age+=5;
        console.log("after" +this.age);
    }

    render(){

    return(
        <div>
        <p>Age :{this.props.age}</p>
       <button onClick={()=>this.update()}>Update Age </button>
       </div> 
    )
    }
}
export default Event1;