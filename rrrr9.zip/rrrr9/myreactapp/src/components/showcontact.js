import React  from 'react'

export class ShowContact extends React.Component {

    render()
     {
        return(
          <div>
            <h1> Show Contact</h1>
            <table border="1" >
                <tr>
                    <th>Contactname</th>
                    <th>Contactnumber</th>
                </tr>
             <tbody>
                {this.props.contacts.map((contact)=>    <tr key={contact}>
                <td>{contact.contactname} </td>
               <td>{contact.contactnumber} </td>
               <td> <button class="btn btn-danger" onClick={()=>this.props.deleteContact(contact.id)}>X</button>
               </td>
               </tr>
                  )}
                  </tbody>
               
                   
           
               
                
            </table>
            </div>
           
        )
    }
}
export default ShowContact;