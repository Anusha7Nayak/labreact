import React  from 'react'
import CustomerDisplay from './customerdisplay';

export class CustomerInfo extends React.Component {
    constructor()
    {
        super()
        {
            this.state={
                user:{
                    userName:'',
                    userEmail:'',
                    userMobile:'',
                    userAddress:'',
                    userDescription:'',
                    userDateofVisit:''
                  

                },
                display:false//user end
            }
            // state end
        }//super end
    }// constructor end
    
    //step 4
    handleSubmit(e)
    { alert(`${this.state.user.userName}`)
    alert(`${this.state.user.userEmail}`)

    alert(`${this.state.user.userMobile}`)
    alert(`${this.state.user.userAddress}`)
    alert(`${this.state.user.userDescription}`)
    alert(`${this.state.user.userDateofVisit}`)
        e.preventDefault();
        this.setState({display:true});
console.log(this.state.user.userName);
console.log(this.state.user.userEmail);
console.log(this.state.user.userMobile);
console.log(this.state.user.userAddress);
console.log(this.state.user.userDescription);
console.log(this.state.user.userDateofVisit);
    }
    UpdateState(ctrl,value){
        const{user}=this.state;//get the current state value
        user[ctrl]=value;//update the user entered data
        this.setState({user});//update the new user

    }

    resetState(){
        this.setState(
            {
            user:{
                userName:'',
                userEmail:'',
                userMobile:'',
                userAddress:'',
                userDescription:'',
                userDateofVisit:''
              

            }
        }
        )
           
}
    render() 
    {
        const {user} =this.state;

        return(
            <div>
            <h1> State Add and Delete</h1>
            {/* //step 3 */}
            <form onSubmit={(e)=>this.handleSubmit(e)}> 
                <label> UserName</label>
                {/* //step2 */}
                <input type="text" value={user.userName} onChange={(e)=>this.UpdateState('userName',e.currentTarget.value)}/>
                <br/>
                <label> Email</label>
                <input type="text" value={user.userEmail}onChange={(e)=>this.UpdateState('userEmail',e.currentTarget.value)}/>
                <br/>

                <label> Mobile</label>
                <input type="text" value={user.userMobile}onChange={(e)=>this.UpdateState('userMobile',e.currentTarget.value)}/>
                <br/>

                <label> Address</label>
                <input type="text"value={user.userAddress}onChange={(e)=>this.UpdateState('userAddress',e.currentTarget.value)}/>
                <br/>

                <label> Description</label>
                <input type="text" value={user.userDescription}onChange={(e)=>this.UpdateState('userDescription',e.currentTarget.value)}/>
                <br/>

                <label> User Date of visit</label>
                <input type="text" value={user.userDateofVisit}onChange={(e)=>this.UpdateState('userDateofVisit',e.currentTarget.value)}/>
                <br/>
                <button type="submit"> Submit</button>

            </form>
            { this.state.display ?
            <CustomerDisplay userData={this.state.user}deleteCustomer={(e)=>this.resetState()}/>
            :null}
            </div>
        )
    }
}

export default CustomerInfo;