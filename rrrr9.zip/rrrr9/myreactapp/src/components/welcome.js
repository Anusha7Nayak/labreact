import React,{Component} from 'react'

export class Welcome extends Component {
    render(){
        let message="";
        if(true) {
            message="Hello viju";
        }
    
        return (
            <div>   
            <h1>Hello from welcome component</h1>
            <p>{2+2}</p>
            <p>{message}</p>
            <button className="btn btn-primary">Click</button>
             {/* React.createElement('h1',null,'Hello world') */}
            </div>
        )
    }
}
export default Welcome;

 