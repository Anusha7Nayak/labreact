import React from 'react'

export class State extends React.Component {
    constructor(props){
        super(props)
        this.state={
count:this.props.count
            
        }
        }

    changeMessage() {
        this.count+=1;
this.setState({
count:this.count+=1
})
}  
    
    render()
{
    return(
        <div>
        <p> count-{this.count}</p>
        <button onClick={()=>this.changeMessage()}>Increment</button>
        </div>
    )
}
}
export default State;
