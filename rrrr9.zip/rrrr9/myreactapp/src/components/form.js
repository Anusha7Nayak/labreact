import React  from 'react'

export class Form extends React.Component {
    constructor(props)
    {
        super()
       this.state={
           name:"",
           lastname:'',
           topic:'Angular'
       }
    }
  
    handlechangename=(event)=>
    {
        this.setState(
            {
  name:event.target.value
            }
        )
    }

    handlechangelastname=(event)=>
    {
        this.setState(
            {
  lastname:event.target.value
            }
        )
    }
    handlechangetopic=(event)=>
    {
        this.setState(
            {
  topic:event.target.value
            }
        )
    }

    handleSubmit=(event)=>
    {
        alert(`${this.state.name} ${this.state.lastname}  ${this.state.topic}`)
console.log(this.state.name);
console.log(this.state.lastname);
console.log(this.state.topic);
event.preventDefault();
    }
    render() {
        return(
           <div>
      
          <h1> Form Demo</h1>
        
          <form onSubmit={this.handleSubmit}>
          <div>
      <label>
       Name:
       </label>
    <input type="text" name="name"  value={this.state.name} onChange={this.handlechangename}/>
    </div>

    <div>
         
       
      <label>
       Lastname:
       </label>
    <input type="text" name="lastname"  value={this.state.lastname} onChange={this.handlechangelastname}/>
    </div>
    <div>

         
       
      
         
       
         <label>
         TOPIC:
          </label>
       <select value={this.state.topic} onChange={this.handlechangetopic}>
           <option value="Angular">Angular</option>
           <option value="Node">Node</option>
           <option value="React">React</option>
       </select>
       </div>
       <button type="submit">submit</button>
   </form>
   </div>
         
        )
    }
}
export default Form;