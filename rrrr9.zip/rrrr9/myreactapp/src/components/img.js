import React  from 'react'

export class Image extends React.Component {
    constructor()
    {
        super()
        {
            this.state={
                display:true
                   
                  

                }
                //user end
            }
            // state end
        }//super end

        display1=()=>{
            this.setState({
                display:!this.state.display
                     })
        }
    render()
     {
        return(
            <div>
            <h1> Welcome to Image component</h1>
            <button 
onClick={()=>{this.display1()}}>Change </button>    
 { this.state.display ?<img src={require('../projsrc/download.png')}/>
 :<img src={require('../projsrc/prod1.jpg')}/>
 }

            
            </div>
        )
}
}
export default Image;