import React from 'react'
export class EventDemo extends React.Component{
callEvent(){
    console.log("I am from event");
}

    render() {
       
      return ( <button onClick={()=>this.callEvent()}>Click me </button>
      )
       
    }
}
export default EventDemo;