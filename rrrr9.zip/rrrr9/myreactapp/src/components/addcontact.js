import React  from 'react'

export class AddContact extends React.Component {
    //step1
    contactname=React.createRef();
    contactnumber=React.createRef();
handleAddContact=()=>{
    let contObject={contactname:this.contactname.current.value,contactnumber:this.contactnumber.current.value}
    this.props.addContact(contObject)
}
    render()
     {
        return(
            <div className="well">
            <h1> Add Contacts</h1>
            <form>
                {/* //step2 add ref to input field */}
            contactname:<input ref={this.contactname}/>
            <br/>
           contactnumber: <input  ref={this.contactnumber}/>
           <br/>
            <button onClick={this.handleAddContact} class="btn btn-success">ADD</button>
            </form>
            </div>
            
        )
    }
}
export default AddContact;