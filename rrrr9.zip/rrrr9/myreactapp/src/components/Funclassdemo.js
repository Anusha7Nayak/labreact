import React from 'react'

export const Funclassdemo=()=>{
    return <h1> this is my functional component</h1>
}
export default Funclassdemo;