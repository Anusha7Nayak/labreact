import React from 'react'

export const Greeting=(props)=> {
    return <h1>Hello {props.name}</h1>
}
export default Greeting;