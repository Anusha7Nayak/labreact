import React, { Component } from 'react'
import {BrowserRouter as Router, Route, Link } from 'react-router-dom'
import Category1 from './Category1'
import Category2 from './Category2'
import Category3 from './Category3'


export class Navigation extends Component {
  render() {
   
  return (
    <Router>
      <ul>
        <Link to="/samsung">Samsung</Link> 
        <br/>
        <Link to="/mi">Mi </Link>
        <br/>
        <Link to="/nokia">Nokia</Link>
        <br/>
      </ul>
      <Route path="/samsung" component={Category1} />
      <Route path="/mi" component={Category2} />
      <Route path="/nokia" component={Category3} />
    </Router>
  );

}

}
export default Navigation;