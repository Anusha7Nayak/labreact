import React, { Component } from "react";

export class Category3 extends Component {
  render() {
    return (
      <div>
        <img src ={require ('./nokia.jpg')}/>
        <h1>Description</h1>
        <p>
          DescriptionNokia Corporation is a Finnish multinational
          telecommunications, information technology, and consumer electronics
          company, founded in 1865. Nokia's headquarters are in Espoo, in the
          greater Helsinki metropolitan area.
        </p>
      </div>
    );
  }
}

export default Category3;
