import React, { Component } from 'react';

import './App.css';
import NameForm from './components/inputtext';
import Select from 'react-select';

// const techCompanies = [
//   { label: "Apple", value: 1 },
//   { label: "Facebook", value: 2 },
//   { label: "Netflix", value: 3 },
//   { label: "Tesla", value: 4 },
//   { label: "Amazon", value: 5 },
//   { label: "Alphabet", value: 6 },
// ];

// const App = () => (
//   <div className="container">
//     <div className="row">
//       <div className="col-md-4"></div>
//       <div className="col-md-4">
//         <Select options={ techCompanies } />
//       </div>
//       <div className="col-md-4">
//       <NameForm/>
//       </div>
//     </div>
//   </div>
// );



class App extends Component {
  constructor(props){
    super(props)
    this.state={lable:''
  ,
   techCompanies :[
    { label: "Apple", value: 1 },
    { label: "Facebook", value: 2 },
    { label: "Netflix", value: 3 },
    { label: "Tesla", value: 4 },
    { label: "Amazon", value: 5 },
    { label: "Alphabet", value: 6 },
  ]}

  }
newtech
  lableHandle=(lable)=>{
    console.log(lable)
    let newlable={
  lable:"",value:''};

  
  let length=this.state.techCompanies.length
   newlable.value=this.state.techCompanies[length-1].value+1


    newlable.lable=lable
    console.log(newlable)
    
     this.newtech=this.state.techCompanies.push(newlable)
    this.setState({
       techCompanies:this.newtech

    })
    console.log(this.state.techCompanies)
  }
  render() {
    return (
      <div className="container">
    <div className="row">
      <div className="col-md-4"></div>
      <div className="col-md-4">
        <Select options={ this.state.techCompanies} />
      </div>
      <div className="col-md-4">
      <NameForm lable={this.state.lable} lableHandle={this.lableHandle}/>
      </div>
    </div>
  </div>
    );
  }
}

export default App;
