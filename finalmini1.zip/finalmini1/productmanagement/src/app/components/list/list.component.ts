import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/model/product';
import { ProductService } from 'src/app/service/product.service';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  products:Product[];
  config: any; 
  collection = [];

  constructor(private route: ActivatedRoute,private productservice:ProductService,private router:Router) { this.config = {
    currentPage: 1,
    itemsPerPage:5
};

this.route.queryParamMap
      .map(params => params.get('page'))
      .subscribe(page => this.config.currentPage= page);

for (let i = 1; i <= 100; i++) {
this.collection.push(`item ${i}`);
}

}


pageChange(newPage: number) {
this.router.navigate(['list'], { queryParams: { page: newPage }});
}

  ngOnInit() {
    if(localStorage.getItem("username")!=null) {
    this. productservice.getproducts().subscribe(data=>{
      this.products=data;
    });
  
    //new
    
    
  }
  else{
    this.router.navigate(['/login']);
  }
  
    }
    updateproduct(pro:Product):void{
      localStorage.removeItem("editUserId")
      localStorage.setItem("editUserId",pro.id.toString());
      this.router.navigate(['edit']);
  
    }
    addproduct(): void
  {
    this.router.navigate(['add']);
  }
  deleteproduct(pro:Product):void{
    let result=confirm("Do you want to delete user")
    if(result) {
      this.productservice.deleteproduct(pro.id).subscribe(data=>{
        this.products=this.products.filter(u=> u!==pro);
      })
    }
  }
 
  }

