import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  editForm:FormGroup;
  submitted:boolean=true;

  constructor(private formbuilder:FormBuilder,private router:Router, 
    private productservice:ProductService) { }

  ngOnInit() {
    if(localStorage.getItem("username")!=null) {
      let productId=localStorage.getItem("editUserId");
      if(!productId){
        alert("invalid action");
        this.router.navigate(['list']);
        return;
      }
    this.productservice.getproductById(+productId).subscribe(data=>{
        this.editForm.setValue(data)
      });
      this.editForm=this.formbuilder.group({
        id:['',Validators.required],
        name:['',Validators.required],
       description:['',Validators.required],
       price:['',Validators.required]

      });

  
      
    }
   

else {
  this.router.navigate(['/login']);
}
}
onsubmit(){
  this.submitted=true;
 if(this.editForm.invalid){
   return;
  }
  this.productservice.updateproduct(this.editForm.value)
  .subscribe(data=> {alert(this.editForm.value.name + "" +'record edited')

  });


  this.router.navigate(['list']);
}
}
