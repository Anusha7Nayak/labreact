var mongodb = require("mongodb");
var mongoClient1 = mongodb.MongoClient;
var url = "mongodb://localhost:27017/emp";
mongoClient1.connect(url, function (err, client) {
  if (err) console.log(err);
  else {
    console.log("Connection established" + url);
    var db = client.db("emp");
    //update using ID-1002 
    var myquery = { empId: 1006 };

    var newvalues = { $set: { empName: "Akshatha" } };
    db.collection("emps").updateMany(myquery, newvalues,
       function (err,result
    ) {
      if (err) console.log(err);
      else {
        console.log("  Record Modified");
      }
    });
    
    
  }
  client.close();
  
});