var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/emp';
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established", url);
        var db = client.db('emp');
        var collection = db.collection('emps');

        //specified range
        collection.find({"empAddress.state":"California"}).toArray(function(err,res){
            if(err){
                console.log(err);
            }else{
                console.log(res);
            }
                });
    
    
            
    }
});