var mongodb = require("mongodb");
var mongoClient1 = mongodb.MongoClient;
var url = "mongodb://localhost:27017/items";
mongoClient1.connect(url, function (err, client) {
  if (err) console.log(err);
  else {
    console.log("Connection established" + url);
    var db = client.db("items");
    //update using ID-1002 
    var myquery = { prodid: 1002 };

    var newvalues = { $set: { prodname: "sofa" } };
    db.collection("item").updateMany(myquery, newvalues,
       function (err,result
    ) {
      if (err) console.log(err);
      else {
        console.log("  Record Modified");
      }
    });
    
    
  }
  client.close();
  
});