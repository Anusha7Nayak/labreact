var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/items';
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established", url);
        var db = client.db('items');
        var collection = db.collection('item');
        collection.remove({'prodid':1001},function(err,res){
            if(err){
                console.log(err);
            }else
            {
                console.log('%s',res);
            }
        });
       
    }
});