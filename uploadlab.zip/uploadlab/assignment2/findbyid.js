var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/items';
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established", url);
        var db = client.db('items');
        var collection = db.collection('item');

        //specified range
       
    collection.find({prodid:1001}).toArray(function(err,res){
        if(err){
            console.log(err);
        }else{
            console.log(res);
        }
            });


            
    }
});