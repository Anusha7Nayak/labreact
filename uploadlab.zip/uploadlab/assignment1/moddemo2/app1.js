
var Emp = require('./lib/employee');

empOne=new Emp.data(1001,'rashmi',8888.88);
empTwo=new Emp.data(1002,'parth',8888.88);
empThree=new Emp.data(1003,'Anusha',8888.88);
empFour=new Emp.data(1004,'Akshatha',8888.88);
empFive=new Emp.data(1005,'rashmi',8888.88);
empSix=new Emp.data(1006,'RAj',8888.88);
Emp.set(empOne);
Emp.set(empTwo);
Emp.set(empThree);
Emp.set(empFour);
Emp.set(empFive);
Emp.set(empSix);
Emp.get();

