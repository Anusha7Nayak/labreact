import React, { Component } from 'react'
import{BrowserRouter as Router,Route,Link,Switch} from 'react-router-dom';

export class Welcomepage extends Component {
  render() {
    const user =this.props.userData;
    return (
      <div>
        
      
        <h3>Welcome {user.userName}</h3>
      </div>
    )
  }
}

export default Welcomepage
