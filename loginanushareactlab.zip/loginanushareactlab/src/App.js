import React, { Component } from 'react';
import './App.css';
import Login from './component/Login';


class App extends Component {
  render() {
    return (
      <div>
   <Login/>
 
      </div>
  
    );
  }
}

export default App;
