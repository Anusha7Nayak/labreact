import { Injectable } from "@angular/core";
import { Product } from "../model/product";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class ProductService {
  baseurl: string = "http://localhost:3000/Product";

  getproducts() {
    return this.http.get<Product[]>(this.baseurl);
  }

  deleteproduct(id: number) {
    return this.http.delete<Product[]>(this.baseurl + "/" + id);
  }
  createproduct(product: Product) {
    return this.http.post(this.baseurl, product);
  }
  updateproduct(product: Product) {
    return this.http.put(this.baseurl + "/" + product.id, product);
  }

  getproductById(id: number) {
    return this.http.get<Product>(this.baseurl + "/" + id);
  }

  constructor(private http: HttpClient) {}
}
