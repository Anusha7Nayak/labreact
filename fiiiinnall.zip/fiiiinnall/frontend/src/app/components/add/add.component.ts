import { Component, OnInit } from "@angular/core";
import { FormGroup, Validators, FormControl } from "@angular/forms";
import { ProductService } from "src/app/service/product.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-add",
  templateUrl: "./add.component.html",
  styleUrls: ["./add.component.css"]
})
export class AddComponent implements OnInit {
  addForm: FormGroup;
  submitted: boolean = false;
  constructor(private router: Router, private productservice: ProductService) {}

  ngOnInit() {
    this.addForm = new FormGroup({
       id:new FormControl(),
        _id: new FormControl("", [
        Validators.required,
        Validators.pattern("[0-9]{1,4}")
      ]),
      name: new FormControl("", [
        Validators.required,
        Validators.pattern("[A-Z][a-z]+")
      ]),
      description: new FormControl("", [Validators.required]),
      price: new FormControl("", Validators.required)
    });
    
  }
  onSubmit() {
    this.submitted = true;
    if (this.addForm.invalid) {
      return;
    }
    this.productservice.createproduct(this.addForm.value).subscribe(data => {
      alert(this.addForm.value.name + "" + "record added");
     
      
    
    });

    this.router.navigate(["list"]);
  }
}
