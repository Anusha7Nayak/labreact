import { Component, OnInit }
  from '@angular/core';

import { FormGroup, FormBuilder, Validators }
  from '@angular/forms';

import { Router }
  from '@angular/router';

// import { AuthenticationService } from 'src/app/services/authentication.service';









@Component({

  selector: 'app-login',

  templateUrl: './login.component.html',

  styleUrls: ['./login.component.css']

})

export class LoginComponent
  implements OnInit {

    loginForm:FormGroup;
    submitted:boolean=false;
    invalidLogin:boolean=false;
  
    constructor( private formBuilder:FormBuilder,private router:Router) { }
  
    ngOnInit() {
      this.loginForm=this.formBuilder.group({
       username:['',Validators.required],
        password:['',Validators.required]
      });
    }
    onSubmit()
  {
    this.submitted=true;
    //if validation fails it should return to validate again
    if(this.loginForm.invalid)
    {
      return true;
    }
    let username=this.loginForm.controls.username.value;
    if(this.loginForm.controls.username.value=="admin@gmail.com"
     && this.loginForm.controls.password.value=="123456") 
     {
       localStorage.setItem("username",username);  // to check user exist or not 
       this.router.navigate(['list']);
     }
     else {
       this.invalidLogin=true;
     }
  }
  
  
    
    
  }
  